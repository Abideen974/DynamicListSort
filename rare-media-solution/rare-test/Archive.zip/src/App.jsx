
import './App.css'
import DynamicListSort from './components/DynamicListSort'

function App() {
  return (
    <>
     <DynamicListSort />
    </>
  )
}

export default App
