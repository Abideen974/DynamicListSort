export const POST_DATA = [
    { id: 1, title: "Post One", content: "This is the first post", date: "2023-11-01" },
    { id: 2, title: "Post Two", content: "This is the second post", date: "2023-11-02" },
    { id: 3, title: "Post Three", content: "This is the third post", date: "2023-11-03" },
    { id: 4, title: "Post Four", content: "This is the fourth post", date: "2023-11-04" },
    { id: 5, title: "Post Five", content: "This is the fifth post", date: "2023-11-05" },
    { id: 6, title: "Post Six", content: "This is the sixth post", date: "2023-11-06" },
    { id: 7, title: "Post Seven", content: "This is the seventh post", date: "2023-11-07" },
    { id: 8, title: "Post Eight", content: "This is the eighth post", date: "2023-11-08" },
    { id: 9, title: "Post Nine", content: "This is the ninth post", date: "2023-11-09" },
    { id: 10, title: "Post Ten", content: "This is the tenth post", date: "2023-11-10" },
    { id: 11, title: "Post Eleven", content: "This is the eleventh post", date: "2023-11-11" },
    { id: 12, title: "Post Twelve", content: "This is the twelfth post", date: "2023-11-12" },
    { id: 13, title: "Post Thirteen", content: "This is the thirteenth post", date: "2023-11-13" },
    { id: 14, title: "Post Fourteen", content: "This is the fourteenth post", date: "2023-11-14" },
    { id: 15, title: "Post Fifteen", content: "This is the fifteenth post", date: "2023-11-15" }
  ];
